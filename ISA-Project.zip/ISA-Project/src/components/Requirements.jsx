import React, { useState, useEffect } from "react";
import axios from "axios";
import { useLocation, useNavigate } from "react-router-dom";
import "./Requirements.css"; // Import the CSS file
const Requirements = () => {
  const [examSections, setExamSections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { search } = useLocation();
  const navigate = useNavigate();

  const queryParams = new URLSearchParams(search);
  const teacherCourseId = queryParams.get("teacherCourseId");
  const teacherName = queryParams.get("teacherName");
  const courseName = queryParams.get("courseName");

  useEffect(() => {
    if (teacherCourseId) {
      setLoading(true);
      axios
        .get(
          `http://localhost:5000/api/exam_sections?teacherCourseId=${teacherCourseId}`
        )
        .then((response) => {
          console.log("Exam sections data:", response.data); // Debug the response
          setExamSections(response.data);
          setLoading(false);
        })
        .catch((error) => {
          console.error("Error fetching exam sections:", error);
          setError("Failed to fetch exam sections.");
          setLoading(false);
        });
    } else {
      console.error("Invalid teacherCourseId:", teacherCourseId);
      setError("Invalid teacherCourseId.");
      setLoading(false);
    }
  }, [teacherCourseId]);

  return (
    <div className="content-container">
      <h1>Question Paper Requirements</h1>
      <h2>
        Teacher: {teacherName} - Course: {courseName}
      </h2>

      {loading ? (
        <p>Loading exam sections...</p>
      ) : error ? (
        <p>{error}</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Exam Section</th>
              <th>Student Count</th>
            </tr>
          </thead>
          <tbody>
            {examSections.length > 0 ? (
              examSections.map((section, index) => (
                <tr key={index}>
                  <td>{section.exam_section_name}</td>
                  <td>{section.student_count}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="2">No exam sections found.</td>
              </tr>
            )}
          </tbody>
        </table>
      )}

      <button onClick={() => navigate(-1)}>Go Back</button>
    </div>
  );
};

export default Requirements;
