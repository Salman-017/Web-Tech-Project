import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import SemesterDivisionSelector from "./components/SemesterDivisionSelector";
import TeacherCourseList from "./components/TeacherCourseList";
import Requirements from "./components/Requirements";

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<SemesterDivisionSelector />} />
        <Route path="/teachers" element={<TeacherCourseList />} />
        <Route path="/requirements" element={<Requirements />} />
      </Routes>
    </Router>
  );
};

export default App;
