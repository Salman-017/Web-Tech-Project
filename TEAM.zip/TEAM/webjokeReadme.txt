Setting up the vite-project.
	step 1, create assessment database in wamp server.	
	step 2. go to newtt.js file in \vite-project\src\assets\components run node newtt.js for table creation in ass. database.
	step 2. run server.js for connection of database in vite-project\src\assets\components\database
	step 3 . Do npm init in vite-project.
	step 4. login is admin and pass is admin@123 and other faculty_...
	step 5. Kaddapa team box name is next module .
	step 5. Ansh team box name is student division.
	

God is great. 